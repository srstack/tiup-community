# case13 - PreserveOwner

https://github.com/otiai10/copy/issues/48
