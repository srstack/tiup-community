This `.gitfake` directory is an imitation of `.git`.
In most cases, we don't want to copy `.git` directory.