# Case 11

When the source contains named pipes.

Note: Github doesn't support tracking named pipes, so we keep the folder for the test case itself.