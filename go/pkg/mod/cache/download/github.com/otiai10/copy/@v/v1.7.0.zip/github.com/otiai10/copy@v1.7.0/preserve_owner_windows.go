//+build windows

package copy

func preserveOwner(src, dest string, info fileInfo) (err error) {
	return nil
}
