// Copyright 2016 Canonical Ltd.
// Licensed under the LGPLv3, see LICENCE file for details.

// Package ansiterm provides a Writer that writes out the ANSI escape
// codes for color and styles.
package ansiterm
