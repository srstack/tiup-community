#!/usr/bin/env bash
docker build . -t tikv/kvproto:3.8.0
